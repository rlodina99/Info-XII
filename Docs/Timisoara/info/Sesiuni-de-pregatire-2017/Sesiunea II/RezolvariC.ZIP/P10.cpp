/*
 suma Riemann - exemplu utilizare parametri de tip functie
*/
#include <iostream.h>
#include <math.h>
float f1(float x)
{return (x);}   

float f2(float x)
{return (sin(x)+cos(x));}

float S(int n, float (*f)(float),float a, float b)
{float h, suma, x;
 int i;
 suma=0;
 h=(b-a)/n;
 x=a;
 for(i=1;i<=n;i++)
   {suma=suma+(*f)(x);
    x=x+h;
    }
 suma=h*suma;
 return suma;      
}      

float sumaRiemann(float (*f)(float),float a, float b)
{float h, x, sant, scrt, eps=0.00001;
 int i, n=1;
 h=(b-a)/n;
 scrt=h*f(a);
 do {sant=scrt; 
     n++;     
     scrt=S(n,f,a,b);   
     } while (fabs(scrt-sant)>=eps);
  return (scrt);       
}       

int main()
{float a,b,rez; 
 cout<<"a="; cin>>a;
 cout<<"b="; cin>>b;
 cout<<sumaRiemann(f1,a,b)<<endl;
 getchar(); getchar();
}      
 
