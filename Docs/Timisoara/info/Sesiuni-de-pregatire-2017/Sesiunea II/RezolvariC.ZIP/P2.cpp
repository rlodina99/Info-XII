/* P2:  cel mai mic si cel mai mare numar de k cifre care au suma cifrelor 
   egala cu o valoare data */
#include <iostream.h>
/* calcul suma cifrelor */
int sumaCifre(int n)
{int s=0;
 while (n>0)
  {s=s+n%10;
   n=n/10;
  } 
 return s;
}
/* determinarea celui mai mic si a celui mai mare numar ce satisfac proprietatile
   returnarea valorile prin parametri de iesire (de tip referinta)
*/
void cauta(int k, int s, int& min, int& max)
{int i,nr,inf,sup;
 min=-1;
 max=-1;
 inf=1;
 for(i=1;i<k;i++)
   inf=inf*10; 
 sup=10*inf-1;
 nr=inf;  
 while (nr<=sup)
   if (sumaCifre(nr)==s)
      {min=nr;
       break;
      }  
   else
      nr=nr+1;   
 nr=sup;
 while (nr>=inf)
   if (sumaCifre(nr)==s)
      {max=nr;
       break;
      } 
   else
      nr=nr-1;  
}   

/* determinarea celui mai mic si a celui mai mare numar ce satisfac proprietatile
   returnarea valorile prin parametri de iesire (de tip adresa)
*/
/*void cauta(int k, int s, int *min, int *max)
{int i,nr,inf,sup;
 *min=-1;
 *max=-1;
 inf=1;
 for(i=1;i<k;i++)
   inf=inf*10; 
 sup=10*inf-1;
 nr=inf;  
 while (nr<=sup)
   if (sumaCifre(nr)==s)
      {*min=nr;
       break;
      }  
   else
      nr=nr+1;   
 nr=sup;
 while (nr>=inf)
   if (sumaCifre(nr)==s)
      {*max=nr;
       break;
      } 
   else
      nr=nr-1;  
}   
*/
                         
int main()
{int s, k, min, max;
 cout<<"k=";
 cin>>k;
 cout<<"s=";
 cin>>s;
 cauta(k,s,min,max);
// cauta(k,s,&min,&max); // varianta cu transmiterea de adrese pentru parametrii de iesire
 cout<<"min="<<min<<endl;
 cout<<"max="<<max<<endl;
 getchar(); getchar();
} 
