/* P1 suma factorialelor cifrelor A(n)*/
#include <iostream.h>
#include <limits.h>

/* calcul factorial */
int fact(int c)
{int i,f=1;   
 for(i=2;i<=c;i++)
   f=f*i;
 return f;    
}

/* calcul suma factoriale cifre */
int calculA(int n)
{int a=0; 
 if (n==0) return 1;  
 while (n>0)
   {a=a+fact(n%10);
    n=n/10;
//    cout<<"a="<<a<<"n="<<n<<endl;
   }
 return a;    
}

/* cel mai mic numar cu proprietatea ca A(n)=k */
int cauta(int k)
{long i,s;
 for (i=0;i<=LONG_MAX;i++)
   {s=calculA(i);
    if (s==k) return(i);    
   }
 return(-1);
}   

int caut(int k)
{int i=1, exist; 
 i=1;
 exist=0;   
 while ((exist==0)&&(i<INT_MAX))
   {if(k==calculA(i))
      exist=1;  
    else
      i++;
   } 
 if (exist)
   return i;
 else
   return -1;     
}

                         
int main()
{int n, k, rez,nr=0;
 cout<<"n=";
 cin>>n;
 printf("A(n)=%d",calculA(n));
 //cin>>k;
 for(k=1;k<9999;k++){
   rez=caut(k);               
   printf("k=%d, n=%d \n",k,rez);
   if (rez==-1) nr++; //{getchar(); getchar();}
   }
 cout<<"nr="<<nr<<endl;  
 getchar(); getchar();
} 
