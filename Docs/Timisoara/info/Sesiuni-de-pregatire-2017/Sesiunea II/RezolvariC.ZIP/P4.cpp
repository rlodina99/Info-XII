/* P4: calcul perimetru, arie, nr laturi poligon convex dat prin coordonatele 
   carteziene ale varfurilor (in ordine trigonometrica)
*/
#include <iostream.h>
#include <math.h>
/* calcul distanta euclidiana intre doua puncte */
float dist(float x1, float y1, float x2, float y2)
{return(sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));}
/* calcul semiperimetru triunghi dat prin lungimile laturilor */
float semiperimetru(float a, float b, float c)
{return((a+b+c)/2);}
/* calcul arie triunghi folosind formula lui Heron pornind de la lungimile 
   laturilor
*/
float arieTriunghi(float a, float b, float c)
{float p;
 p=semiperimetru(a,b,c);
 return(sqrt(p*(p-a)*(p-b)*(p-c)));
 }     
/* verificare proprietate de coliniaritate pentru 3 puncte date prin coordonatele 
   carteziene */
int coliniare(float x1, float y1, float x2, float y2, float x3, float y3) 
{float eps=0.00001;
 // in cazul datelor de tip real valorile sunt aproximative deci o conditie de 
 // egalitate se specifica printr-o inegalitate:  val=0 e inlocuit cu |val|<eps 
 // cu eps o valoare suficient de mica
 if (fabs((x2-x1)*(y3-y1)-(y2-y1)*(x3-x1))<eps) return(1); else return(0);
} 
/* calculul perimetrului */
float perimetru(int n)
{int i;
 float x1, y1, xant, yant, xcrt, ycrt, p;
 p=0;
 cout<<"x1="; cin>>x1; xcrt=x1;
 cout<<"y1="; cin>>y1; ycrt=y1;
 for(i=2;i<=n;i++)
  {xant=xcrt; yant=ycrt; // coordonatele punctului anterior
   cout<<"x"<<i<<"="; cin>>xcrt; // coordonatele punctului curent
   cout<<"x"<<i<<"="; cin>>ycrt;
   p=p+dist(xant,yant,xcrt,ycrt);
  }
 p=p+dist(xcrt,ycrt,x1,y1);
 return p;       
}    

/* calculul ariei = suma ariilor triunghiurilor determinate de punctele
 P(x1,y1), P(xant,yant), P(xcrt,ycrt)
*/
float arie(int n)
{int i;
 float x1, y1, xant, yant, xcrt, ycrt, a;
 float dP1Pant,dP1Pcrt;
 a=0;
 cout<<"x1="; cin>>x1; 
 cout<<"y1="; cin>>y1; 
 cout<<"x2="; cin>>xcrt; 
 cout<<"y2="; cin>>ycrt; 
 dP1Pcrt=dist(x1,y1,xcrt,ycrt);
 for(i=3;i<=n;i++)
  {xant=xcrt; yant=ycrt; 
   dP1Pant=dP1Pcrt;
   cout<<"x"<<i<<"="; cin>>xcrt;
   cout<<"x"<<i<<"="; cin>>ycrt;
   dP1Pcrt=dist(x1,y1,xcrt,ycrt);
   a=a+arieTriunghi(dP1Pant,dist(xant,yant,xcrt,ycrt),dP1Pcrt);
  }
 return a;       
}   

/* determinarea coordonatelor coltului din stanga jos si a celui din dreapta sus
*/
void dreptunghi(int n, float& xmin, float &ymin, float& xmax, float& ymax)
{int i;
 float x,y;
 cout<<"x1="; cin>>x; 
 cout<<"y1="; cin>>y; 
 xmin=xmax=x; ymin=ymax=y;
 for(i=2;i<=n;i++)
  {cout<<"x"<<i<<"="; cin>>x;
   cout<<"x"<<i<<"="; cin>>y;
   if (x<xmin) xmin=x; if (x>xmax) xmax=x;
   if (y<ymin) ymin=y; if (y>ymax) ymax=y;
  }    
}   

/* determinarea numarului efectiv de laturi:  daca Pcrt nu este coliniar cu 
   ultimele doua puncte anterioare atunci trebuie contorizata o noua latura,
   altfel numarul de laturi nu se incrementeaza
   
*/

int nrLaturi(int n)
{int i, nr;
 float x1,y1,xcrt,ycrt,xant,yant,xant2,yant2;   
 cout<<"x1="; cin>>x1; xant=x1;
 cout<<"y1="; cin>>y1; yant=y1;
 cout<<"x2="; cin>>xcrt; 
 cout<<"y2="; cin>>ycrt;
 nr=1;
 for(i=3;i<=n;i++)
  {xant2=xant; yant2=yant;
   xant=xcrt; yant=ycrt; 
   cout<<"x"<<i<<"="; cin>>xcrt;
   cout<<"x"<<i<<"="; cin>>ycrt;
   if (coliniare(xant2,yant2,xant,yant,xcrt,ycrt)==0) nr++;
  }
 if (coliniare(xant,yant,xcrt,ycrt,x1,y1)==0) nr++;  
 return nr; 
}  
                    
int main()
{int n,nr;
 float perimetruPoligon=0, ariePoligon=0;
 float xmin, ymin, xmax, ymax;
 cout<<"n="; cin>>n;
 perimetruPoligon=perimetru(n);
/* ariePoligon=arie(n);
 dreptunghi(n,xmin,ymin,xmax,ymax);
 nr=nrLaturi(n); */
 cout<<"Perimetru poligon="<<perimetruPoligon<<endl;
/* cout<<"Arie poligon="<<ariePoligon<<endl;
 cout<<"Numar laturi="<<nr<<endl;
 cout<<"Dreptunghi:("<<xmin<<","<<ymin<<"),("<<xmax<<","<<ymax<<")"<<endl;
*/ 
 getchar(); getchar();
} 
 /*int n,i;
 float x1, y1;
 float xant2, yant2, xant, yant, xcrt, ycrt;
 float distP1Pant, distPantPcrt, distP1Pcrt;
 int nrLaturi=1;
 float perimetruPoligon=0, ariePoligon=0;
 float xmin, ymin, xmax, ymax;
 cout<<"n=";
 cin>>n;
 cout<<"x1="; cin>>x1; xant=xmin=xmax=x1;
 cout<<"y1="; cin>>y1; yant=ymin=ymax=y1;
 cout<<"x2="; cin>>xcrt;
 cout<<"y2="; cin>>ycrt;
 if(xcrt<xmin) xmin=xcrt; if(ycrt<ymin) ymin=ycrt; 
 if(xcrt>xmax) xmax=xcrt; if(ycrt>ymax) ymax=ycrt; 
 distP1Pcrt=dist(x1,y1,xcrt,ycrt);
 perimetruPoligon += distP1Pcrt;
 for (i=3;i<=n;i++)
 {xant2=xant; yant2=yant;
  xant=xcrt; yant=ycrt;
  distP1Pant=distP1Pcrt;
  cout<<"x"<<i<<"="; cin>>xcrt;
  cout<<"y"<<i<<"="; cin>>ycrt;
  if(xcrt<xmin) xmin=xcrt; if(ycrt<ymin) ymin=ycrt; 
  if(xcrt>xmax) xmax=xcrt; if(ycrt>ymax) ymax=ycrt;
  distPantPcrt=dist(xant,yant,xcrt,ycrt);
  distP1Pcrt=dist(x1,y1,xcrt,ycrt);
  perimetruPoligon += distPantPcrt;
  ariePoligon += arie(distP1Pant,distPantPcrt,distP1Pcrt);
  if (coliniar(xant2,yant2,xant,yant,xcrt,ycrt)!=1) nrLaturi++;
}
 perimetruPoligon += distP1Pcrt;
 cout<<"Perimetru poligon="<<perimetruPoligon<<endl;
 cout<<"Arie poligon="<<ariePoligon<<endl;
 cout<<"Numar laturi="<<nrLaturi<<endl;
 cout<<"Dreptunghi:("<<xmin<<","<<ymin<<"),("<<xmax<<","<<ymax<<")"<<endl;
 getchar(); getchar();
} 
*/
