/* P3: Generare valoare naturala pornind de la 0 prin operatii de incrementare si 
   dublare
*/
#include <iostream.h>

/* Afisare operatii (in ordinea inversa a aplicarii) + determinare numar minim 
   de operatii (pt orice numar par ultima operatie aplicata este de dublare iar pentru 
   orice numar impar ultima operatie aplicata este de incrementare)
   
   Varianta iterativa cu contorizare separata a numarului de incrementari si 
   numarului de dublari
   
   Parametrii de iesire nrinc si nrdub sunt specificati ca adrese (functioneaza 
   si in C) 
*/   
void operatiiIterativ(int n, int *nrinc, int *nrdub)
{*nrinc=0;
 *nrdub=0;  
 while(n>0)
   if (n%2==0)
    {cout<<"dublare "; n=n/2; (*nrdub)++;}
   else 
    {cout<<"incrementare "; n=n-1; (*nrinc)++;}     
}   

/* Varianta recursiva cu contorizare cumulata a numarului de incrementari si 
   numarului de dublari (daca afisarea operatiei este plasata dupa apelul recursiv
   atunci operatiile vor fi afisate in ordinea aplicarii lor)
   
   Parametrul de iesire nr este specificat ca referinta (doar in C++) 

*/
void operatiiRecursiv(int n, int& nr)
{nr=nr+1;  // la fiecare apel se efectueaza o operatie
 if (n==1) {cout<<"incrementare"<<endl; }
 else if (n%2==0) { operatiiRecursiv(n/2,nr); cout<<"dublare"<<endl; }
       else {operatiiRecursiv(n-1,nr);  cout<<"incrementare"<<endl;} 
}      
              
int main()
{int n, nrinc, nrdub, nr=0;
 cout<<"n=";
 cin>>n;
 operatiiIterativ(n,&nrinc, &nrdub);
 cout<<"nrinc="<<nrinc;
 cout<<"nrdub="<<nrdub<<endl;
 operatiiRecursiv(n,nr);
 cout<<"nr="<<nr<<endl;
 getchar(); getchar();
} 
