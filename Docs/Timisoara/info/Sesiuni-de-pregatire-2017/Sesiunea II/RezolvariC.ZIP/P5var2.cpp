/* P5:  Operatii cu numere complexe
   - evaluarea unui polinom cu coeficienti reali pentru un argument numar complex
*/   
#include <iostream.h>
#include <math.h>
typedef struct{float real; float imag;} complex;
/* suma a doua numere complexe date prin partea reala si coeficientul partii imaginare */
complex suma(complex a, complex b)
{complex s;
 s.real=a.real+b.real;
 s.imag=a.imag+b.imag;
 return(s);
}
/* produsul a doua numere complexe */
complex produs(complex a, complex b)
{complex p;
 p.real=a.real*b.real-a.imag*b.imag;
 p.imag=a.real*b.imag+a.imag*b.real;
 return(p);
} 

char oper(float vimag)
{if (vimag>0) return('+'); else return('-');}
 
int main()
{
 complex z,v,c;
 float  creal;
 int n,i;
 cout<<"n="; cin>>n;
 cout<<"z - parte reala="; cin>>z.real;
 cout<<"z - parte imaginara="; cin>>z.imag;
 cout<<"c"<<n<<"="; cin>>c.real;
 c.imag=0;
 v=c; 
 for(i=n-1;i>=0;i--)
   {v=produs(v, z);
    cout<<"c"<<i<<"="; cin>>c.real;
    v=suma(v, c); 
   } 
 cout<<v.real<<oper(v.imag)<<fabs(v.imag)<<"i";  
 getchar(); getchar();
}      
 
