/*
 P7: Se considera un serviciu web la care utilizatorii se conecteaza/deconecteaza si 
 se pune problema determinarii numarului maxim de utilizatori conectati simultan 
 pornind de la o secventa de semnale de forma:  1 (s-a conectat un utilizator), 
 0 (s-a deconectat un utilizator). 
De exemplu pentru secventa 1,1,1,0,1,0,1,1,1,0,0,1,0,0,0 numarul maxim de 
utilizatori conectati este 5.
*/
#include <iostream.h>

int main()
{int s,conect,conectMax;
 int n,i;
 cout<<"n="; cin>>n;
 conect=conectMax=0;
 for(i=1;i<=n;i++)
   {
    cout<<"s"<<i<<"="; cin>>s;
    if(s==1) conect++; 
    else {if (conect>conectMax) conectMax=conect;
          conect--;
         }  
   } 
 
 cout<<"Nr maxim="<<conectMax;  
 getchar(); getchar();
}      
 
