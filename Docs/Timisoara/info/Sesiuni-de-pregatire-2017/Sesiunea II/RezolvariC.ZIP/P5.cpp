/* P5:  Operatii cu numere complexe
   - evaluarea unui polinom cu coeficienti reali pentru un argument numar complex
*/   
#include <iostream.h>
#include <math.h>
/* suma a doua numere complexe date prin partea reala si coeficientul partii imaginare */
void suma(float areal, float aimag, float breal, float bimag, float& sreal, float& simag)
{sreal=areal+breal;
 simag=aimag+bimag;}
/* produsul a doua numere complexe */
void produs(float areal, float aimag, float breal, float bimag, float& preal, float& pimag)
{preal=areal*breal-aimag*bimag;
 pimag=areal*bimag+aimag*breal;} 

char oper(float vimag)
{if (vimag>0) return('+'); else return('-');}
 
int main()
{
 float zreal, zimag, c, vreal, vimag;
 int n,i;
 cout<<"n="; cin>>n;
 cout<<"z - parte reala="; cin>>zreal;
 cout<<"z - parte imaginara="; cin>>zimag;
 cout<<"c"<<n<<"="; cin>>vreal;
 vimag=0; // evaluare polinom folosind ideea de la schema lui Horner
 for(i=n-1;i>=0;i--)
   {produs(vreal, vimag, zreal, zimag, vreal, vimag);
    cout<<"c"<<i<<"="; cin>>c;
    suma(vreal, vimag, c, 0, vreal, vimag); 
   } 
 cout<<vreal<<oper(vimag)<<fabs(vimag)<<"i";  
 getchar(); getchar();
}      
 
