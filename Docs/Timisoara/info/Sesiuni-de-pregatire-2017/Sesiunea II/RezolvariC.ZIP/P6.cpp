/*
P6:
- cea mai lung subsecventa crescatoare 
- subsecventa de suma maxima

*/   
#include <iostream.h>

void lgMaxima(int n, int& indMaxCresc, int& lgMax)
{float x, xant;
 int lgCresc;   // lg curenta
 int indCresc;  // indice secventa crescatoare curenta
 cout<<"x"<<1<<"="; cin>>x;
 lgCresc=lgMax=1; indCresc=indMaxCresc=1;
 for(int i=2;i<=n;i++)
   {
    xant=x; //retinerea elementului anterior  - necesar pentru comparare
    cout<<"x"<<i<<"="; cin>>x;
    if (xant>x) 
       {if (lgCresc>lgMax) 
           {lgMax=lgCresc; indMaxCresc=indCresc;}; 
        lgCresc=1; indCresc=i;}
    else {lgCresc=lgCresc+1;}
    }     
}  

float sumaMaxima(int n, int& startMax, int& endMax)
{float x, suma, sumaMax;
 int start, end;    
 cout<<"x"<<1<<"="; cin>>x;
 if (x<0) 
    {suma=0; start=end=startMax=endMax=2;}
 else 
    {suma=x; start=end=startMax=endMax=1;}
 sumaMax=suma;   
 for(int i=1;i<=n;i++)
   {cout<<"x"<<i<<"="; cin>>x;
    if (suma+x<0) 
       {suma=0; start=i+1;} // daca suma devine negativa se reseteaza
    else 
       {suma=suma+x; end=i;
        if (suma>sumaMax) 
           {sumaMax=suma; 
            startMax=start; 
            endMax=end;
           } 
       } 
   }
  return sumaMax;  
}   

int main()
{int n, indMaxCresc, lgMax;
 int startMax, endMax;
 float sumaMax;
 cout<<"n="; cin>>n;
// lgMaxima(n,indMaxCresc,lgMax);
// cout<<"Lg maxima="<<lgMax<<" indice 1:"<<indMaxCresc<<" indice 2:"<<indMaxCresc+lgMax-1<<endl;
 sumaMax=sumaMaxima(n,startMax, endMax);
 cout<<"Suma maxima="<<sumaMax<<"indice 1:"<<startMax<<"indice 2:"<<endMax;  
 getchar(); getchar();
}      
 
