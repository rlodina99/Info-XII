/*
 P9: secventa Collatz
*/
#include <iostream.h>
/* calcul valoare din secventa */
int C(int n)
{if (n%2==0) return(n/2);
 else return(3*n+1);
}   
/* determinare lungime secventa */
int L(int n)
{int k,lg;
 k=n;
 lg=1;
 while (k!=1)
  {k=C(k); lg++;}
 return(lg); 
}

int main()
{int a,b,n1,n2; 
 cout<<"a="; cin>>a;
 cout<<"b="; cin>>b;
 for(n1=a;n1<=b-1;n1++)
   for(n2=n1+1;n2<=b;n2++)
     if (L(n1)==L(n2)) cout<<"("<<n1<<","<<n2<<")"<<endl;
 getchar(); getchar();
}      
 
