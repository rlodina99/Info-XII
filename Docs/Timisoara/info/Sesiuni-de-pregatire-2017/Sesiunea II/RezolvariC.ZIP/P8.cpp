/*
 Netezire unei secvente de valori prin mediere folosind o fereastra de dimensiune 3
*/
#include <iostream.h>

int main()
{float xant2, xant, xcrt; 
 int n,i;
 cout<<"n="; cin>>n;
 cout<<"x0="; cin>>xant;
 cout<<"x1="; cin>>xcrt;
 for(i=2;i<n;i++)
   {xant2=xant;
    xant=xcrt;
    cout<<"x"<<i<<"="; cin>>xcrt;
    cout<<"y"<<i-1<<"="<<(xant2+xant+xcrt)/3;
   } 
 getchar(); getchar();
}      
 
